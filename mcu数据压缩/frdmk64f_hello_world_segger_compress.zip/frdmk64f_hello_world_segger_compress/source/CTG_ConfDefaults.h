/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File        : CTG_ConfDefaults.h
Purpose     : Defines defaults for most configurable defines used in
              the library.  If you want to change a value, please do
              so in CTG_Conf.h, DO NOT modify this file.

*/

#ifndef CTG_CONFDEFAULTS_H
#define CTG_CONFDEFAULTS_H

#ifdef __cplusplus
extern "C" {
#endif

#include <string.h>
//#include "SEGGER.h"
#include "CTG_Conf.h"

// Default to non-debug release build
#ifndef   DEBUG
  #define DEBUG 0
#endif

#ifndef CTG_DEBUG
  #if DEBUG > 0
    #define CTG_DEBUG      1      // Default for debug builds
  #else
    #define CTG_DEBUG      0      // Default for release builds
  #endif
#endif

#ifndef CTG_INOUT_BUFF_SIZE
  #define CTG_INOUT_BUFF_SIZE        32
#endif

#ifndef CTG_SANITY_CHECK
  #define CTG_SANITY_CHECK        CTG_DEBUG
#endif

#ifndef   CTG_MEMSET
  #define CTG_MEMSET     memset
#endif

#ifdef __cplusplus
}
#endif

#endif

/*************************** End of file ****************************/
