/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : CTG.h
Purpose : emCompress-ToGo public header file.

*/

#ifndef CTG_H            // Avoid multiple inclusion.
#define CTG_H

#if defined(__cplusplus)
  extern "C" {                // Make sure we have C-declarations in C++ programs.
#endif

#include "CTG_ConfDefaults.h"
#include "Global.h"

/*********************************************************************
*
*       Defines, fixed
*
**********************************************************************
*/
#define CTG_MAX_REFERENCE_LEN              258u          // Maximum length in references
#define CTG_MAX_REFERENCE_LEN_BITS          15u          // Length of references are encoded in max. 15 bits

/*********************************************************************
*
*       Version number
*
*  Description
*    Symbol expands to a number that identifies the specific emCompress-ToGo release.
*/
#define CTG_VERSION               32000   // Format is "Mmmrr" so, for example, 31000 corresponds to version 3.10.

/*********************************************************************
*
*       Function status values
*
*  Description
*    Compression and decompression errors.
*
*  Additional information
*    Values returned as errors by the compression and decompression
*    functions.  All errors are negative.
*/
#define CTG_STATUS_OUTPUT_OVERFLOW     (-100)     // The output buffer is not big enough to contain the compressed or decompressed output.
#define CTG_STATUS_INPUT_UNDERFLOW     (-101)     // The input buffer contains a bitstream that is truncated.
#define CTG_STATUS_BUFFER_TOO_SMALL    (-102)     // The work buffer provided to the compressor or decompressor is too small.
#define CTG_STATUS_BAD_PARAMETER       (-103)     // A parameter given to the function is invalid.
#define CTG_STATUS_DECODING_ERROR      (-104)     // Error while decoding, bad encoded data stream.

/*********************************************************************
*
*       Window size parameter
*
*  Description
*    Sets the window size to use when compressing.
*
*  Additional information
*    Smaller windows will make compression run faster, larger
*    windows tend to make the compressed output smaller.
*/
#define CTG_FLAG_WINDOW_SIZE_256    0u      // Window set to 256 bytes
#define CTG_FLAG_WINDOW_SIZE_512    1u      // Window set to 512 bytes
#define CTG_FLAG_WINDOW_SIZE_1K     2u      // Window set to 1K bytes
#define CTG_FLAG_WINDOW_SIZE_2K     3u      // Window set to 2K bytes
#define CTG_FLAG_WINDOW_SIZE_4K     4u      // Window set to 4K bytes
#define CTG_FLAG_WINDOW_SIZE_8K     5u      // Window set to 8K bytes
#define CTG_FLAG_WINDOW_SIZE_16K    6u      // Window set to 16K bytes

/*********************************************************************
*
*       Workspace buffer sizes
*
*  Description
*    Gives the size of the workspace required for compression and
*    decompression depending on the 'Flags' parameter (CTG_FLAG_WINDOW_SIZE_...)
*    used during compression.
*/
#define CTG_COMPRESS_WS_SIZE(Flags)       ((0x100uL << (Flags)) + CTG_MAX_REFERENCE_LEN)   // Gives the workspace size required
                                                                                           // for compression functions depending
                                                                                           // on the window size used.
#define CTG_DECOMPRESS_WS_SIZE(Flags)     (0x100uL << (Flags))                             // Gives the workspace size required
                                                                                           // for decompression functions depending
                                                                                           // on the window size used for compression.
#define CTG_FCOMPRESS_M_WS_SIZE(Flags)    ((0x200uL << (Flags)) + 512u)                    // Gives the workspace size required
                                                                                           // for the fast compression functions from
                                                                                           // memory depending on the window size used.
#define CTG_FCOMPRESS_WS_SIZE(Flags)      ((0x300uL << (Flags)) + CTG_MAX_REFERENCE_LEN + 512u)  // Gives the workspace size required
                                                                                           // for the fast compression
                                                                                           // functions depending on the window size used.

/*********************************************************************
*
*       Types, global
*
**********************************************************************
*/

/*********************************************************************
*
*       CTG_STREAM
*
*  Description
*    Streaming interface for compression / decompression.
*/
typedef struct {
  unsigned   AvailIn;  // Number of elements available as input octets.
  const U8 * pIn;      // Pointer to available input octets.
  int        Flush;    // Set to 1, if no more input data are available.
  unsigned   AvailOut; // Size of buffer for output data.
  U8       * pOut;     // Pointer to the buffer for output data.
} CTG_STREAM;


/*********************************************************************
*
*       CTG_COMPRESS_CTX
*
*  Description
*    Compress context used for streaming compression functions.
*/
typedef struct {
  unsigned               WorkLen;
  unsigned               InLen;
  unsigned               WLen;
  U32                    OutData;
  unsigned               OutBits;
  U8                   * pWork;
  unsigned               WindowSize;
  unsigned               LastDist;
  unsigned               FixedDistBits;
  I8                     End;
  unsigned               Cursor;
  int                    Status;
} CTG_COMPRESS_CTX;


/*********************************************************************
*
*       CTG_DECOMPRESS_CTX
*
*  Description
*    Decompress context used for streaming decompression functions.
*/
typedef struct {
  int                    Status;
  U32                    Data;
  int                    NumBits;
  U32                    DataRem;
  unsigned               BitsRem;
  unsigned               BitNum;
  U8                   * pWork;
  unsigned               MaxDist;
  unsigned               LastDist;
  unsigned               FixedDistBits;
  U32                    FixedDistMask;
  unsigned               OutCursor;
  unsigned               RefCursor;
  unsigned               RefLen;
  unsigned               WorkLen;
} CTG_DECOMPRESS_CTX;


/*********************************************************************
*
*       CTG_RD_FUNC()
*
*  Description
*    Read data form source. The function must provide at least one byte of
*    data to the caller, except if the end of the input data is reached.
*    If the function returns a negative value, the compression/decompression
*    operation will be aborted and the value if forward to
*    the caller of the compression/decompression function.
*
*  Parameters
*    pData   - Pointer to object that receives the data.
*    DataLen - Maximum number of bytes to read into object, will be nonzero.
*    pRdCtx  - Client-supplied read context.
*
*  Return value
*    <  0 - Error reading data.
*    == 0 - Success, end of stream, no further data.
*    >  0 - Success, number of bytes placed into object, more data to read.
*/
typedef int (CTG_RD_FUNC)(U8 *pData, unsigned DataLen, void *pRdCtx);

/*********************************************************************
*
*       CTG_WR_FUNC()
*
*  Description
*    Write data to sink. The function must consume all 'DataLen' bytes of data.
*    If the function returns a negative value, the compression/decompression
*    operation will be aborted and the value if forward to
*    the caller of the compression/decompression function.
*
*  Parameters
*    pData   - Pointer to object to write.
*    DataLen - Number of bytes to write.
*    pWrCtx  - Client-supplied read context.
*
*  Return value
*    <  0 - Error writing data.
*    == 0 - Success.
*/
typedef int (CTG_WR_FUNC)(const U8 *pData, unsigned DataLen, void *pWrCtx);


/*********************************************************************
*
*       CTG_COMPRESS_RD_CTX
*
*  Description
*    Compress context used for CTG_CompressRead() function.
*/
typedef struct {
  CTG_STREAM             Stream;
  U8                   * pBuff;
  unsigned               BuffSize;
  CTG_RD_FUNC          * pfRd;
  void                 * pRdCtx;
  CTG_COMPRESS_CTX       Ectx;
} CTG_COMPRESS_RD_CTX;

/*********************************************************************
*
*       CTG_COMPRESS_WR_CTX
*
*  Description
*    Compress context used for CTG_CompressWrite() function.
*/
typedef struct {
  CTG_STREAM             Stream;
  U8                   * pBuff;
  unsigned               BuffSize;
  CTG_WR_FUNC          * pfWr;
  void                 * pWrCtx;
  CTG_COMPRESS_CTX       Ectx;
} CTG_COMPRESS_WR_CTX;

/*********************************************************************
*
*       CTG_DECOMPRESS_RD_CTX
*
*  Description
*    Compress context used for CTG_DecompressRead() function.
*/
typedef struct {
  CTG_STREAM             Stream;
  U8                   * pBuff;
  unsigned               BuffSize;
  CTG_RD_FUNC          * pfRd;
  void                 * pRdCtx;
  CTG_DECOMPRESS_CTX     Dctx;
} CTG_DECOMPRESS_RD_CTX;

/*********************************************************************
*
*       CTG_DECOMPRESS_WR_CTX
*
*  Description
*    Compress context used for CTG_CompressWrite() function.
*/
typedef struct {
  CTG_STREAM             Stream;
  U8                   * pBuff;
  unsigned               BuffSize;
  CTG_WR_FUNC          * pfWr;
  void                 * pWrCtx;
  CTG_DECOMPRESS_CTX     Dctx;
} CTG_DECOMPRESS_WR_CTX;

/*********************************************************************
*
*       API functions
*
**********************************************************************
*/

/*********************************************************************
*
*       One-call compression functions
*/
int          CTG_CompressM2M        (const U8 *pInput, unsigned InputLen, U8 *pOutput, unsigned OutputSize, unsigned Flags);
int          CTG_CompressM2F        (const U8 *pInput, unsigned InputLen, CTG_WR_FUNC *pfWr, void *pWrCtx, unsigned Flags);
int          CTG_CompressF2M        (CTG_RD_FUNC *pfRd, void *pRdCtx, U8 *pOutput, unsigned OutputSize, U8 *pWork, unsigned WorkLen, unsigned Flags);
int          CTG_CompressF2F        (CTG_RD_FUNC *pfRd, void* pRdCtx, CTG_WR_FUNC *pfWr, void *pWrCtx, U8 *pWork, unsigned WorkLen, unsigned Flags);
int          CTG_FastCompressM2M    (const U8 * pInput, unsigned InputLen, U8 * pOutput, unsigned OutputSize, U16 * pWork, unsigned WorkLen, unsigned Flags);
int          CTG_FastCompressM2F    (const U8 * pInput, unsigned InputLen, CTG_WR_FUNC * pfWr, void * pWrCtx, U16 * pWork, unsigned WorkLen, unsigned Flags);

/*********************************************************************
*
*       One-call decompression functions
*/
int          CTG_DecompressM2M      (const U8 *pInput, unsigned InputLen, U8 *pOutput, unsigned OutputSize);
int          CTG_DecompressM2F      (const U8 *pInput, unsigned InputLen, CTG_WR_FUNC *pfWr, void *pWrCtx, U8 *pWork, unsigned WorkLen);
int          CTG_DecompressF2M      (CTG_RD_FUNC pfRd, void *pRdCtx, U8 *pOutput, unsigned OutputSize);
int          CTG_DecompressF2F      (CTG_RD_FUNC pfRd, void *pRdCtx, CTG_WR_FUNC *pfWr, void *pWrCtx, U8 *pWork, unsigned WorkLen);

/*********************************************************************
*
*       Multi-call compression functions (streaming interface)
*/
void         CTG_CompressInit       (CTG_COMPRESS_CTX *pCtx, U8 *pWork, unsigned WorkLen, unsigned Flags);
int          CTG_Compress           (CTG_COMPRESS_CTX *pCtx, CTG_STREAM *pStream);

void         CTG_CompressReadInit   (CTG_COMPRESS_RD_CTX *pCtx, U8 *pWork, unsigned WorkLen, U8 *pBuff, unsigned BuffSize, CTG_RD_FUNC * pfRd,  void * pRdCtx, unsigned Flags);
int          CTG_CompressRead       (CTG_COMPRESS_RD_CTX *pCtx, U8 *pBuff, unsigned NumBytes);

void         CTG_CompressWriteInit  (CTG_COMPRESS_WR_CTX *pCtx, U8 *pWork, unsigned WorkLen, U8 *pBuff, unsigned BuffSize, CTG_WR_FUNC * pfWr, void * pWrCtx, unsigned Flags);
int          CTG_CompressWrite      (CTG_COMPRESS_WR_CTX *pCtx, const U8 *pData, unsigned NumBytes);

/*********************************************************************
*
*       Multi-call decompression functions (streaming interface)
*/
void         CTG_DecompressInit     (CTG_DECOMPRESS_CTX *pCtx, U8 *pWork, unsigned WorkLen);
int          CTG_Decompress         (CTG_DECOMPRESS_CTX *pCtx, CTG_STREAM *pStream);

void         CTG_DecompressReadInit (CTG_DECOMPRESS_RD_CTX *pCtx, U8 *pWork, unsigned WorkLen, U8 *pBuff, unsigned BuffSize, CTG_RD_FUNC * pfRd,  void * pRdCtx);
int          CTG_DecompressRead     (CTG_DECOMPRESS_RD_CTX *pCtx, U8 *pBuff, unsigned NumBytes);

void         CTG_DecompressWriteInit(CTG_DECOMPRESS_WR_CTX *pCtx, U8 *pWork, unsigned WorkLen, U8 *pBuff, unsigned BuffSize, CTG_WR_FUNC * pfWr,  void * pWrCtx);
int          CTG_DecompressWrite    (CTG_DECOMPRESS_WR_CTX *pCtx, const U8 *pData, unsigned NumBytes);

/*********************************************************************
*
*       Status decode functions
*/
const char * CTG_GetStatusText      (int Status);

/*********************************************************************
*
*       Version and copyright information
*/
const char * CTG_GetVersionText     (void);
const char * CTG_GetCopyrightText   (void);


/*********************************************************************
*
*       One-call functions with fixed parameters (obsolete)
*/
#define CTG_CompressM2M_256(pInput, InputLen, pOutput, OutputLen)   CTG_CompressM2M(pInput, InputLen, pOutput, OutputLen, CTG_FLAG_WINDOW_SIZE_256)
#define CTG_CompressM2M_512(pInput, InputLen, pOutput, OutputLen)   CTG_CompressM2M(pInput, InputLen, pOutput, OutputLen, CTG_FLAG_WINDOW_SIZE_512)
#define CTG_CompressM2M_1k (pInput, InputLen, pOutput, OutputLen)   CTG_CompressM2M(pInput, InputLen, pOutput, OutputLen, CTG_FLAG_WINDOW_SIZE_1k)
#define CTG_CompressM2M_2k (pInput, InputLen, pOutput, OutputLen)   CTG_CompressM2M(pInput, InputLen, pOutput, OutputLen, CTG_FLAG_WINDOW_SIZE_2k)
#define CTG_CompressM2M_4k (pInput, InputLen, pOutput, OutputLen)   CTG_CompressM2M(pInput, InputLen, pOutput, OutputLen, CTG_FLAG_WINDOW_SIZE_4k)
#define CTG_CompressM2M_8k (pInput, InputLen, pOutput, OutputLen)   CTG_CompressM2M(pInput, InputLen, pOutput, OutputLen, CTG_FLAG_WINDOW_SIZE_8k)
#define CTG_DecompressM2M_256                                       CTG_DecompressM2M
#define CTG_DecompressM2M_512                                       CTG_DecompressM2M
#define CTG_DecompressM2M_1k                                        CTG_DecompressM2M
#define CTG_DecompressM2M_2k                                        CTG_DecompressM2M
#define CTG_DecompressM2M_4k                                        CTG_DecompressM2M
#define CTG_DecompressM2M_8k                                        CTG_DecompressM2M

#if defined(__cplusplus)
}                             // Make sure we have C-declarations in C++ programs.
#endif

#endif

/*************************** End of file ****************************/
