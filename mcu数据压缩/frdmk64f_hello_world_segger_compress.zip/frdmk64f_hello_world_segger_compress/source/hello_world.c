/*
 * Copyright (c) 2013 - 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"
#include "CTG.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */

//static const uint8_t _aInput[] = {"Jabberwocky\n BY LEWIS CARROLL\n\n\n"
//"'Twas brillig, and the slithy toves\n Did gyre and gimble in the wabe:\n"
//"All mimsy were the borogoves,\n And the mome raths outgrabe.\n\n"
//"\"Beware the Jabberwock, my son!\n The jaws that bite, the claws that catch!\n"
//"Beware the Jubjub bird, and shun\n The frumious Bandersnatch!\"\n\n"
//"He took his vorpal sword in hand;\n Long time the manxome foe he sought-\n"
//"So rested he by the Tumtum tree\n And stood awhile in thought.\n\n"
//"And, as in uffish thought he stood,\n The Jabberwock, with eyes of flame,\n"
//"Came whiffling through the tulgey wood,\n And burbled as it came!\n\n"
//"One, two! One, two! And through and through\n The vorpal blade went snicker-snack!\n\n"
//"He left it dead, and with its head\n He went galumphing back.\n\n"
//"\"And hast thou slain the Jabberwock?\n Come to my arms, my beamish boy!\n"
//"O frabjous day! Callooh! Callay!\"\n\n He chortled in his joy.\n"
//"'Twas brillig, and the slithy toves\n Did gyre and gimble in the wabe:\n"
//"All mimsy were the borogoves,\n And the mome raths outgrabe.\n"};

extern unsigned char _acfrdmk64f_hello_world_segger_compress[13224UL + 1];

static uint8_t _aOutput[sizeof(_acfrdmk64f_hello_world_segger_compress)*2];
static uint8_t _aMirror[sizeof(_acfrdmk64f_hello_world_segger_compress)];

void myCompress()
{
	int EncodeLen;
	int DecodeLen;
	float rate;

	EncodeLen = CTG_CompressM2M(&_acfrdmk64f_hello_world_segger_compress[0], sizeof(_acfrdmk64f_hello_world_segger_compress),&_aOutput[0], sizeof(_aOutput),0);
	if (EncodeLen >= 0)
	{
		rate = (float)(EncodeLen)/sizeof(_acfrdmk64f_hello_world_segger_compress) *100;
		PRINTF("Compressed %u to %u bytes.\r\n", sizeof(_acfrdmk64f_hello_world_segger_compress), EncodeLen);
		PRINTF("Compressed rate %d%%.\r\n", (uint8_t)rate);
	}
	else
	{
		PRINTF("Compression error.\r\n");
	}
	DecodeLen = CTG_DecompressM2M(&_aOutput[0], EncodeLen,&_aMirror[0], sizeof(_aMirror));
	if(DecodeLen >= 0)
	{
		if(memcmp(_acfrdmk64f_hello_world_segger_compress, _aMirror, DecodeLen) == 0)
		{
			PRINTF("Image match\r\n");
		}
	}
}

int main(void)
{
    char ch;

    /* Init board hardware. */
    BOARD_InitPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    PRINTF("hello world.\r\n");
//    extern void MainTask(void);
//    MainTask();
    myCompress();
    while (1)
    {
        ch = GETCHAR();
        PUTCHAR(ch);
    }
}
